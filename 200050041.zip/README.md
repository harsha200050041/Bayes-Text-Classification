---------------------------------------------------
Assignment 2 : Naive Bayes Text Classification
Roll No : 200050041
---------------------------------------------------

-----------------------------------
1) Pre Processing
-----------------------------------
To create the json files just run the script.py files. 
        >python3 script.py

It creates 2 json files namely bbow_vecs.json and cbow_vecs.json.


------------------------------------
2) Classification
------------------------------------
Laplace smoothing parameter = 1
Run the file bah.py
        >python3 bah.py
Enter absolute path of the file which is to be predicted
You get bbow prediction and cbow prediction.
